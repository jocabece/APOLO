<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;
//Get All Customers
$app->get('/api/customers',function(Request $request, Response $response) {
 $sql="select * from Public.\"usuario\"";
 try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
     $con= $db->connect();
     $stmt=pg_query($con,$sql);
     $clientes=pg_fetch_all($stmt);
     $db=null;
     echo json_encode($clientes);
 }catch(PDOException $e){
     echo '{"error" {"text": '.$e->getMessage().'}';

 }
});
//Get Single Customer
$app->get('/api/customer/{id}',function(Request $request, Response $response) {
    $id = $request->getAttribute('id');
    $sql="select * from Public.\"usuario\" WHERE \"codusuario\"=$id";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $cliente=pg_fetch_all($stmt);
        $db=null;
        echo json_encode($cliente);
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//Verificacion del login
$app->get('/api/customer/verificar/{nom}/{pas}',function(Request $request, Response $response) {
    $nom = $request->getAttribute('nom');
    $pas = $request->getAttribute('pas');
    $sql="select * from Public.\"usuario\" WHERE \"nombreusuario\"='$nom' and \"password\"='$pas' ";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
              if(pg_num_rows($stmt)>0){
                  echo json_encode(true);
        }
        else{
                  echo json_encode(false);

        }
        $db=null;
                    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//todos los Productos
$app->get('/api/productos/total',function(Request $request, Response $response) {
    $sql="select * from Public.\"producto\"";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $productos=pg_fetch_all($stmt);
            echo json_encode($productos);


        $db=null;
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//todas las categorias
$app->get('/api/categorias/total',function(Request $request, Response $response) {
    $sql="select * from Public.\"categoria\"";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $categorias=pg_fetch_all($stmt);
        echo json_encode($categorias);
        $db=null;
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';
    }
});
//Cantidades de Productos
$app->get('/api/productos/{nomp}/{cant}',function(Request $request, Response $response) {
    $nomp = $request->getAttribute('nomp');
    $cant= $request->getAttribute('cant');
    $sql="select cantidad from Public.\"producto\" WHERE \"nombreprod\"='$nomp'";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
                $productos=pg_fetch_row($stmt);
if($productos[0]>=$cant){
    echo json_encode($cant);
    $ncant=$productos[0]-$cant;
     $sql2="UPDATE Public.\"producto\" SET \"cantidad\"=$ncant WHERE \"nombreprod\"='$nomp'";
      pg_query($con,$sql2);

}
else{
    echo json_encode("0");
}



        $db=null;
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//Recibir productos
$app->get('/api/productosf/{nomp}/{cant}',function(Request $request, Response $response) {
    $nomp = $request->getAttribute('nomp');
    $cant= $request->getAttribute('cant');
    $sql="SELECT cantidad from Public.\"producto\" WHERE \"nombreprod\"='$nomp'";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $productos=pg_fetch_row($stmt);
        $ncant=$productos[0]+$cant;
            $sql2="UPDATE Public.\"producto\" SET \"cantidad\"=$ncant WHERE \"nombreprod\"='$nomp'";
            pg_query($con,$sql2);


        $db=null;
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';
    }
});
//Usuarios
$app->get('/api/usuarios/total',function(Request $request, Response $response) {
    $sql="select * from Public.\"usuario\"";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $usuarios=pg_fetch_all($stmt);
        echo json_encode($usuarios);


        $db=null;
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
// Add Customer
$app->post('/api/customer/add',function(Request $request, Response $response) {
    $id=$request->getParam('id');
    $nombre = $request->getParam('nombre');
    $apellido = $request->getParam('apellido');
    $edad = $request->getParam('edad');
    $direccion = $request->getParam('direccion');
    $sql="insert into Public.\"Clientes\" (\"ID\",\"Nombre\",\"Apellido\",\"Edad\",\"Direccion\") VALUES 
($1,$2,$3,$4,$5)";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_prepare($con,"insertar",$sql);
                pg_execute($con,"insertar",array($id,$nombre,$apellido,$edad,$direccion));
       echo '{"notice": {"text":"Customer Added"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
// Update Customer
$app->put('/api/customer/update/{id}',function(Request $request, Response $response) {
    $id=$request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $apellido = $request->getParam('apellido');
    $edad = $request->getParam('edad');
    $direccion = $request->getParam('direccion');
    $sql="UPDATE Public.\"Clientes\" SET \"Nombre\"=$1,\"Apellido\"=$2,\"Edad\"=$3,\"Direccion\"=$4 WHERE \"ID\"=$id ";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_prepare($con,"updatear",$sql);
        pg_execute($con,"updatear",array($nombre,$apellido,$edad,$direccion));
        echo '{"notice": {"text":"Customer Updated"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//Get Single Customer
$app->delete('/api/customer/delete/{id}',function(Request $request, Response $response) {
    $id = $request->getAttribute('id');
    $sql="delete from Public.\"Clientes\" WHERE \"ID\"=$id";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_query($con,$sql);
             $db=null;
        echo '{"notice": {"text":"Customer Deleted"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});