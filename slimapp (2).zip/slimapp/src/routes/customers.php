<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;
//Get All Customers
$app->get('/api/customers',function(Request $request, Response $response) {
 $sql="select * from Public.\"Clientes\"";
 try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
     $con= $db->connect();
     $stmt=pg_query($con,$sql);
     $clientes=pg_fetch_all($stmt);
     $db=null;
     echo json_encode($clientes);
 }catch(PDOException $e){
     echo '{"error" {"text": '.$e->getMessage().'}';

 }
});
//Get Single Customer
$app->get('/api/customer/{id}',function(Request $request, Response $response) {
    $id = $request->getAttribute('id');
    $sql="select * from Public.\"proveedor\" WHERE \"nit\"=$id";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        $stmt=pg_query($con,$sql);
        $cliente=pg_fetch_all($stmt);
        $db=null;
        echo json_encode($cliente);
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
// Add Customer
$app->post('/api/customer/add',function(Request $request, Response $response) {
    $id=$request->getParam('id');
    $nombre = $request->getParam('nombre');
    $apellido = $request->getParam('apellido');
    $edad = $request->getParam('edad');
    $direccion = $request->getParam('direccion');
    $sql="insert into Public.\"Clientes\" (\"ID\",\"Nombre\",\"Apellido\",\"Edad\",\"Direccion\") VALUES 
($1,$2,$3,$4,$5)";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_prepare($con,"insertar",$sql);
                pg_execute($con,"insertar",array($id,$nombre,$apellido,$edad,$direccion));
       echo '{"notice": {"text":"Customer Added"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
// Update Customer
$app->put('/api/customer/update/{id}',function(Request $request, Response $response) {
    $id=$request->getAttribute('id');
    $nombre = $request->getParam('nombre');
    $apellido = $request->getParam('apellido');
    $edad = $request->getParam('edad');
    $direccion = $request->getParam('direccion');
    $sql="UPDATE Public.\"Clientes\" SET \"Nombre\"=$1,\"Apellido\"=$2,\"Edad\"=$3,\"Direccion\"=$4 WHERE \"ID\"=$id ";

    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_prepare($con,"updatear",$sql);
        pg_execute($con,"updatear",array($nombre,$apellido,$edad,$direccion));
        echo '{"notice": {"text":"Customer Updated"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});
//Get Single Customer
$app->delete('/api/customer/delete/{id}',function(Request $request, Response $response) {
    $id = $request->getAttribute('id');
    $sql="delete from Public.\"Clientes\" WHERE \"ID\"=$id";
    try{
        //obtener el objeto de la DB
        $db=new db();
        //Conectar
        $con= $db->connect();
        pg_query($con,$sql);
             $db=null;
        echo '{"notice": {"text":"Customer Deleted"}';
    }catch(PDOException $e){
        echo '{"error" {"text": '.$e->getMessage().'}';

    }
});