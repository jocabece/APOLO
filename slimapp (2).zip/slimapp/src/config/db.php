<?php
    class db
    {
        //Properties
        private $dbhost = 'localhost';
        private $dbuser = 'postgres';
        private $dbpass = '8788465';
        private $dbname = 'proyecto';
        private $dbport = "5432";

        public function connect()
        {
            $cadenaConexion = "host=$this->dbhost port=$this->dbport dbname=$this->dbname user=$this->dbuser password=$this->dbpass";

            $conexion = pg_connect($cadenaConexion) or die("Error en la Conexión: " . pg_last_error());
                       return $conexion;
        }
            }
