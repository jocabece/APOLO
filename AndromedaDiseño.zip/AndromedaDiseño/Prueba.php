<?php
/**
 * Created by PhpStorm.
 * User: Carol Hoffmann
 * Date: 6/1/2017
 * Time: 8:49 AM
 */
   ob_start();
   session_start();
?>

<?
// error_reporting(E_ALL);
// ini_set("display_errors", 1);
?>

namespace PRUEBA;


class Prueba
{

}

<?php
$msg = '';

if (isset($_POST['login']) && !empty($_POST['username'])
    && !empty($_POST['password'])) {

    if ($_POST['username'] == 'tutorialspoint' &&
        $_POST['password'] == '1234') {
        $_SESSION['valid'] = true;
        $_SESSION['timeout'] = time();
        $_SESSION['username'] = 'tutorialspoint';

        echo 'You have entered valid use name and password';
    }else {
        $msg = 'Wrong username or password';
    }
}
?>

